===== Serissa to Kusaba X 0.8 Conversion Script =====
	
=== How to use ===

1. Copy s2xk.php and s2kx.sql to the folder containing config.php on your server.
2. Run s2kx.php.
3. Download the full version Kusaba X from http://kusabax.org
4. Make a backup of your current config.php
5. Extract the files that you downloaded where you want them installed. Overwrite everything.
6. If everything went right, congratulations! You are now running Kusaba X 0.8!

== When upgrading to Kusaba X 0.9 ==

7. Once converted, you will need to run the upgrade scripts to upgrade from Kusaba X 0.8 to Kusabax 0.9. These scripts are located in the OTHER directory.