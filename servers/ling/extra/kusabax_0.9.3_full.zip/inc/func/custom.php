<?php
/* Place any functions you create here. Note that this is not meant for module functions, which should be placed in the module's php file. */

?>